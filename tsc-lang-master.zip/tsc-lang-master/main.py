import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
import logging
import os

from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from tqdm import tqdm

from model import Model, set_random_seed
from data import TextDataset


def main():
    dist.init_process_group(backend="nccl")
    local_rank = int(os.environ["LOCAL_RANK"])
    logging.info(f"local_rank: {local_rank}")
    seed = 42
    set_random_seed(seed)
    device = torch.device(f"cuda:{local_rank}")

    kwargs = {"char_size": 200000, "emb": 16, "length_size": 200, "heads": 4}
    model = Model(**kwargs).to(device)
    model = DDP(model, device_ids=[local_rank], output_device=local_rank)

    logging.info(
        f"params: {sum(p.numel() for p in model.parameters())} | "
        f"{sum(p.numel() for p in model.parameters()) * 4 / 1024 / 1024:.2f} MB"
    )

    data_kwargs = {"path": "/home/hupenghui/THUCNews"}
    mdata = TextDataset(**data_kwargs)
    train_sampler = DistributedSampler(mdata, shuffle=True)
    batch_size = 216
    logging.info(f"data size: {len(mdata)}, all batchs: {len(mdata)//batch_size}")

    train_loader = DataLoader(
        mdata,
        batch_size=batch_size,
        sampler=train_sampler,
        drop_last=True,
    )

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    epochs = 1000
    patience = 10
    best_loss = float("inf")
    patience_counter = 0
    model_save_path = "best_model.pth"

    for epoch in range(epochs):
        model.train()
        train_sampler.set_epoch(epoch)

        total_loss = 0.0
        # Use tqdm to monitor progress during training
        # Only rank 0 typically prints to avoid overlapping bars in multi-GPU scenarios
        if dist.get_rank() == 0:
            loader = tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}", leave=True)
        else:
            loader = train_loader

        for train_x in loader:
            train_x = train_x.to(device)
            predict_logits = model(train_x)
            loss = criterion(predict_logits.transpose(1, 2)[:, :, :-1], train_x[:, 1:])

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(train_loader)
        logging.info(
            f"Rank [{dist.get_rank()}], Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.6f}"
        )

        if dist.get_rank() == 0:
            if avg_loss < best_loss:
                best_loss = avg_loss
                patience_counter = 0
                torch.save(model.module.state_dict(), model_save_path)
                logging.info(f"Saved best model with loss: {best_loss:.6f}")
            else:
                patience_counter += 1
                logging.info(f"Patience counter: {patience_counter}/{patience}")

            logging.info(f"eval: {evaluate(model.module, mdata.enc, device)}")

    dist.destroy_process_group()


def evaluate(model, enc, device):
    model.eval()
    input_text = "任天"
    input_ids = enc.encode(input_text)
    input_data = torch.tensor([input_ids], dtype=torch.int, device=device)
    while True:
        logits = model(input_data)[0, -1:, :]
        new_id = torch.argmax(logits, dim=-1)
        logging.info(f"{logits[0,:10].tolist()}")
        if new_id != 199999 and len(input_ids) < 50:
            input_ids.append(new_id.item())
        else:
            break
        input_data = torch.tensor([input_ids[-50:]], dtype=torch.int, device=device)
    return enc.decode(input_ids)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )
    main()
