import torch
import torch.nn as nn
import numpy as np
import random
import torch.optim as optim
import logging
from data import get_enc


# 设置随机种子函数
def set_random_seed(seed, deterministic=True):
    """设置所有随机种子以确保可重复性"""
    random.seed(seed)  # Python 内置随机数生成器
    np.random.seed(seed)  # NumPy 随机数生成器
    torch.manual_seed(seed)  # PyTorch CPU 随机数生成器
    torch.cuda.manual_seed(seed)  # PyTorch GPU 随机数生成器（单 GPU）
    torch.cuda.manual_seed_all(seed)  # PyTorch GPU 随机数生成器（多 GPU）
    if deterministic:
        torch.backends.cudnn.deterministic = True  # 强制 CuDNN 使用确定性算法
        torch.backends.cudnn.benchmark = False  # 禁用 CuDNN 自动优化


class Model(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()
        self.kwargs = kwargs  # 改名避免与super()冲突
        self.char_embedding = nn.Sequential(
            nn.Embedding(kwargs["char_size"], kwargs["emb"]),
            nn.LayerNorm(kwargs["emb"]),
        )
        self.length_embedding = nn.Sequential(
            nn.Embedding(kwargs["length_size"], kwargs["emb"]),
            nn.LayerNorm(kwargs["emb"]),
        )
        self.merge_norm = nn.Sequential(
            nn.Linear(2 * kwargs["emb"], kwargs["emb"]),  # 直接降维，减少内存
            nn.LeakyReLU(),
            nn.Linear(kwargs["emb"], kwargs["emb"]),
            nn.LeakyReLU(),
            nn.Linear(kwargs["emb"], kwargs["emb"]),
            nn.LayerNorm(kwargs["emb"]),
        )
        self.attention_module = nn.ModuleList(
            [
                nn.MultiheadAttention(
                    kwargs["emb"], kwargs["heads"], batch_first=True
                ),  # 加batch_first
                nn.LayerNorm(kwargs["emb"]),  # 精简结构
            ]
        )
        self.predict = nn.Sequential(
            nn.Linear(kwargs["emb"], kwargs["emb"]),
            nn.LeakyReLU(),
            nn.Linear(kwargs["emb"], kwargs["emb"]),
            nn.LeakyReLU(),
            nn.Linear(kwargs["emb"], kwargs["char_size"]),  # 直接映射到输出
        )

    def forward(self, x):
        input_shape = x.shape
        # 直接在需要时计算，避免存储大tensor
        char_emb = self.char_embedding(x)

        # 使用更紧凑的位置编码计算
        pos_idx = torch.arange(input_shape[1], device=x.device)
        pos_emb = self.length_embedding(pos_idx).unsqueeze(0)

        # 即时计算并融合
        embedding = self.merge_norm(
            torch.cat(
                (
                    char_emb,
                    pos_emb.repeat(input_shape[0], 1, 1),
                ),
                dim=-1,
            )
        )

        # 单层注意力机制，减少内存占用
        mask = torch.triu(
            torch.ones(input_shape[1], input_shape[1], device=x.device), diagonal=1
        ).bool()
        attn_emb, _ = self.attention_module[0](
            embedding, embedding, embedding, attn_mask=mask
        )
        attn_emb = self.attention_module[1](attn_emb)

        return self.predict(attn_emb)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )
    # 设置随机种子
    seed = 42  # 你可以选择任何整数作为种子
    set_random_seed(seed)
    kwargs = {"char_size": 200000, "emb": 16, "length_size": 10000, "heads": 4}
    model = Model(**kwargs).to("cuda")
    print(
        "params:",
        sum(p.numel() for p in model.parameters()),
        sum(p.numel() for p in model.parameters()) * 4 / 1024 / 1024,
        "MB",
    )
    model_save_path = "best_model.pth"
    state_dict = torch.load(
        model_save_path, map_location=torch.device("cuda")
    )  # 加载参数
    model.load_state_dict(state_dict)
    enc = get_enc()
    device = "cuda"

    def evaluate(model, enc, device):
        model.eval()
        input_text = "人工智"
        input_ids = enc.encode(input_text)
        input_data = torch.tensor([input_ids], dtype=torch.int, device=device)
        while True:
            logits = model(input_data)[0, -1:, :]
            probs = torch.softmax(logits, dim=-1)
            new_id = torch.multinomial(
                probs, num_samples=1
            ).item()  # 从概率分布中采样一个索引
            logging.info(f"{logits[0,:10].tolist()}")
            if new_id != 199999 and len(input_ids) < 2000:
                input_ids.append(new_id)
            else:
                break
        return enc.decode(input_ids)

    print(evaluate(model, enc, device))
