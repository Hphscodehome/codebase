import tiktoken
from tiktoken.load import load_tiktoken_bpe
from torch.utils.data import Dataset
import os
import numpy as np

char_size = 200000
split_length = 50


def get_enc():
    mergeable_ranks = load_tiktoken_bpe("./gpt4o")
    enc = tiktoken.Encoding(
        name="gpt-4o",
        pat_str=r"""[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]*[\p{Ll}\p{Lm}\p{Lo}\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?|[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]+[\p{Ll}\p{Lm}\p{Lo}\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?|\p{N}{1,3}| ?[^\s\p{L}\p{N}]+[\r\n/]*|\s*[\r\n]+|\s+(?!\S)|\s+""",
        mergeable_ranks=mergeable_ranks,
        special_tokens={"<|endoftext|>": 199999},
    )
    return enc


class TextDataset(Dataset):
    """自定义文本数据集"""

    def __init__(self, **kwargs):
        self.enc = get_enc()
        self.data_path = kwargs["path"]
        all_datas = self.load_path()
        self.data = np.array(self.tokenize_function(all_datas), dtype=np.int64)

    def load_path(self):
        all_datas = []
        sub_paths = os.listdir(self.data_path)
        for i, sub_path in enumerate(sub_paths):
            full_path = os.path.join(self.data_path, sub_path)
            sub_sub_paths = os.listdir(full_path)
            for j, sub_sub_path in enumerate(sub_sub_paths):
                file_path = os.path.join(full_path, sub_sub_path)
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                    all_datas.append(content)
                # if len(all_datas) > 10000:
                #    break
            # if len(all_datas) > 10000:
            #    break
        return all_datas

    def tokenize_function(self, all_datas):
        result = []
        max_length = float("-inf")
        for pair in all_datas:
            result.append(
                self.enc.encode(pair) + [self.enc._special_tokens["<|endoftext|>"]]
            )
            max_length = max(max_length, len(result[-1]))
        returns = []
        for tok_list in result:
            for i in range(0, max(1, len(tok_list) - split_length), split_length // 2):
                split_ = tok_list[i : i + split_length]
                if len(split_) < split_length:
                    split_.extend(
                        [
                            self.enc._special_tokens["<|endoftext|>"]
                            for _ in range(split_length - len(split_))
                        ]
                    )
                returns.append(split_)
        return returns

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


if __name__ == "__main__":
    enc = get_enc()
    text = "你好我是gpt\n"
    tokens = enc.encode(text)
    print(tokens)
    print(enc.decode(tokens), type(enc.decode(tokens)))
